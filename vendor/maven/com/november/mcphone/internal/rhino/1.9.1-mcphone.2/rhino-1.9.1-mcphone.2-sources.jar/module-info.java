module com.november.mcphone.internal.rhino {
    uses com.november.mcphone.internal.rhino.javascript.NullabilityDetector;

    exports com.november.mcphone.internal.rhino.classfile;
    exports com.november.mcphone.internal.rhino.javascript;
    exports com.november.mcphone.internal.rhino.javascript.annotations;
    exports com.november.mcphone.internal.rhino.javascript.ast;
    exports com.november.mcphone.internal.rhino.javascript.commonjs.module;
    exports com.november.mcphone.internal.rhino.javascript.commonjs.module.provider;
    exports com.november.mcphone.internal.rhino.javascript.debug;
    exports com.november.mcphone.internal.rhino.javascript.optimizer;
    exports com.november.mcphone.internal.rhino.javascript.serialize;
    exports com.november.mcphone.internal.rhino.javascript.typedarrays;
    exports com.november.mcphone.internal.rhino.javascript.xml;
    exports com.november.mcphone.internal.rhino.javascript.config;
    exports com.november.mcphone.internal.rhino.javascript.lc.type;

    uses com.november.mcphone.internal.rhino.javascript.RegExpLoader;
    uses com.november.mcphone.internal.rhino.javascript.xml.XMLLoader;
    uses com.november.mcphone.internal.rhino.javascript.config.RhinoPropertiesLoader;

    provides com.november.mcphone.internal.rhino.javascript.RegExpLoader with
            com.november.mcphone.internal.rhino.javascript.regexp.RegExpLoaderImpl;

    requires java.compiler;
    requires jdk.dynalink;
    requires transitive java.desktop;
}
