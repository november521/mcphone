package com.november.mcphone.internal.rhino.javascript.regexp;

import com.november.mcphone.internal.rhino.javascript.RegExpLoader;
import com.november.mcphone.internal.rhino.javascript.RegExpProxy;

/** This class loads the default RegExp implementation. */
public class RegExpLoaderImpl implements RegExpLoader {
    @Override
    public RegExpProxy newProxy() {
        return new RegExpImpl();
    }
}
